# Diagrammer

Generates Schema Diagrams from RDF

## Dependencies

- [ARQ - A Sparql Processor for Jena](https://jena.apache.org/documentation/query/index.html)

TODO: Fallback to rdflib if sparql is not available. Currently not used because of performance issues.

## Installation

```bash
pip install digrdf
```
## Usage

from the command line

```bash

```

